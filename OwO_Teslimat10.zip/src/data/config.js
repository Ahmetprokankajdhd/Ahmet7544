module.exports = {
    

    ACTIVITY_NAME: "BOT_DURUMU",
    BOT_SAHIPLERI: ["SAHIP_ID_1", "SAHIP_ID_2", "BU_SEKILDE_UZATABILIRSINIZ"],
    SELFBOT_TOKENS: ["HESAP_TOKEN_1", "HESAP_TOKEN_2", "BU_SEKILDE_UZATABILIRSINIZ"],
    
    DISCORD_BOT_TOKEN: "DISCORD_BOTUNUZUN_TOKENI",
    DISCORD_CLIENT_ID: "DISCORD_BOTUNUZUN_ID",
    MONGO_URI: "mongodb+srv://783492:XRNbiDdmgthjXOal@cluster0.lbvzua2.mongodb.net/?retryWrites=true&w=majority", // alıcıya özel oluşturuldu.
    
    SUNUCU_ID: "SUNUCU_ID",
    TESLIMAT_KANALI_ID: "OWO_GONDERIMI_YAPILACAK_KANAL_ID",
    LOG_KANALI_ID: "LOG_KANAL_ID",
    LOG_CHANNEL_WEBHOOK_LINK: "LOG_KANAL_WEBHOOK_LINK",
    SISTEM_LOG_KANALI_ID: "BOT_AKTIFLESINCE_LOG_GONDERILECEK_KANAL",
    KOD_YAZILACAK_TESLIM_KANALI: "KOD_KULLANIM_KANALI_ID",

    TESLIMAT_SEKLI: "owo give {user} {cash}",
    WEBHOOK_KOD_ONAYLANDI_BILDIRIMI: "{emoji} Kod onaylandı {member}, lütfen bekleyin.",
    WEBHOOK_TESLIM_BILDIRIMI: "İşlem tamamlandı, **owo cash** yazarak gelip gelmediğini kontrol edin.\n\n**Siparişinizi onaylayıp değerlendirme yapmayı unutmayın!**",
    WEBHOOK_HATA_BILDIRIMI: "Paranız şu anda gönderilemiyor, lütfen size yardımcı olması için bir yetkiliyi etiketleyin.",

    OWO_BOT_ID: "408785106942164992",

};