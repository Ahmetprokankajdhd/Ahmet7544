module.exports = {

    success: "<a:success:1127232987474448434>",
    cancel: "<:cancel:1127232984769105990>",
    notification: "<a:notification:1126605629360971827> "

}